import { useEffect, useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { z } from "zod";
import { Coffee, LogOut, ArrowLeft, User as UserIcon, MailWarning, MailCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

const profileSchema = z.object({
  display_name: z.string().trim().min(1, "Display name is required").max(60),
  avatar_url: z.string().trim().url("Must be a valid URL").max(500).or(z.literal("")),
});

const ProfilePage = () => {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [fetching, setFetching] = useState(true);
  const [saving, setSaving] = useState(false);
  const [displayName, setDisplayName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("display_name, avatar_url")
        .eq("id", user.id)
        .maybeSingle();
      if (error) toast.error(error.message);
      if (data) {
        setDisplayName(data.display_name ?? "");
        setAvatarUrl(data.avatar_url ?? "");
      }
      setFetching(false);
    })();
  }, [user]);

  if (loading) return null;
  if (!user) return <Navigate to="/auth" replace />;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = profileSchema.safeParse({ display_name: displayName, avatar_url: avatarUrl });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        display_name: parsed.data.display_name,
        avatar_url: parsed.data.avatar_url || null,
      })
      .eq("id", user.id);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Profile updated");
  };

  const handleLogout = async () => {
    await signOut();
    toast.success("Signed out");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-cream py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent mb-6 transition-colors">
          <ArrowLeft className="h-4 w-4" /> Back to Coffee Cafe
        </Link>

        <div className="bg-card rounded-3xl shadow-warm p-8 md:p-10">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-2">
              <Coffee className="h-6 w-6 text-accent" />
              <span className="font-display text-xl font-bold">My Profile</span>
            </div>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4" /> Log out
            </Button>
          </div>

          <EmailVerificationNotice user={user} />

          {fetching ? (
            <div className="space-y-4">
              <Skeleton className="h-24 w-24 rounded-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : (
            <>
              <div className="flex items-center gap-5 mb-8 pb-8 border-b border-border">
                <div className="h-20 w-20 rounded-full bg-gradient-warm flex items-center justify-center overflow-hidden shadow-card-warm">
                  {avatarUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={avatarUrl}
                      alt="Avatar"
                      className="h-full w-full object-cover"
                      onError={(e) => ((e.currentTarget.style.display = "none"))}
                    />
                  ) : (
                    <UserIcon className="h-9 w-9 text-primary-foreground" />
                  )}
                </div>
                <div>
                  <div className="font-display text-2xl font-semibold">
                    {displayName || "Coffee lover"}
                  </div>
                  <div className="text-sm text-muted-foreground">{user.email}</div>
                </div>
              </div>

              <form onSubmit={handleSave} className="space-y-5">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Display name</label>
                  <Input
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Your name"
                    maxLength={60}
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Avatar URL</label>
                  <Input
                    value={avatarUrl}
                    onChange={(e) => setAvatarUrl(e.target.value)}
                    placeholder="https://example.com/avatar.jpg"
                    type="url"
                    maxLength={500}
                  />
                  <p className="text-xs text-muted-foreground mt-1.5">
                    Paste a link to an image (optional).
                  </p>
                </div>
                <Button type="submit" variant="hero" disabled={saving} className="w-full">
                  {saving ? "Saving..." : "Save changes"}
                </Button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

const EmailVerificationNotice = ({ user }: { user: { email?: string; email_confirmed_at?: string | null } }) => {
  const [resending, setResending] = useState(false);
  const verified = !!user.email_confirmed_at;

  const resend = async () => {
    if (!user.email) return;
    setResending(true);
    const { error } = await supabase.auth.resend({ type: "signup", email: user.email });
    setResending(false);
    if (error) toast.error(error.message);
    else toast.success("Verification email sent — check your inbox.");
  };

  if (verified) {
    return (
      <div className="mb-6 flex items-center gap-3 rounded-xl border border-border bg-secondary/50 p-4">
        <MailCheck className="h-5 w-5 text-accent shrink-0" />
        <p className="text-sm text-foreground/80">Your email is verified.</p>
      </div>
    );
  }

  return (
    <div className="mb-6 flex flex-col sm:flex-row sm:items-center gap-3 rounded-xl border border-accent/40 bg-accent/10 p-4">
      <MailWarning className="h-5 w-5 text-accent shrink-0" />
      <div className="flex-1 text-sm">
        <p className="font-medium text-foreground">Please verify your email</p>
        <p className="text-muted-foreground">
          We sent a confirmation link to <span className="font-medium">{user.email}</span>.
        </p>
      </div>
      <Button size="sm" variant="outline" onClick={resend} disabled={resending}>
        {resending ? "Sending..." : "Resend email"}
      </Button>
    </div>
  );
};

export default ProfilePage;

