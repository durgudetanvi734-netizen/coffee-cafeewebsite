import Navbar from "@/components/cafe/Navbar";
import Hero from "@/components/cafe/Hero";
import About from "@/components/cafe/About";
import Menu from "@/components/cafe/Menu";
import Specials from "@/components/cafe/Specials";
import Testimonials from "@/components/cafe/Testimonials";
import Gallery from "@/components/cafe/Gallery";
import Newsletter from "@/components/cafe/Newsletter";
import Contact from "@/components/cafe/Contact";
import Footer from "@/components/cafe/Footer";

const Index = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <main>
      <Hero />
      <About />
      <Menu />
      <Specials />
      <Testimonials />
      <Gallery />
      <Newsletter />
      <Contact />
    </main>
    <Footer />
  </div>
);

export default Index;
