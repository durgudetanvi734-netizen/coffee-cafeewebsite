import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/hooks/useTheme";
import { cn } from "@/lib/utils";

interface Props {
  className?: string;
}

const ThemeToggle = ({ className }: Props) => {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={`Switch to ${isDark ? "light" : "dark"} mode`}
      title={`Switch to ${isDark ? "light" : "dark"} mode`}
      className={cn(
        "relative h-9 w-9 rounded-full border border-border/60 bg-background/40 backdrop-blur-md flex items-center justify-center transition-all duration-300 hover:bg-accent/15 hover:border-accent hover:scale-110",
        className
      )}
    >
      <Sun
        className={cn(
          "h-4 w-4 absolute transition-all duration-500",
          isDark ? "opacity-0 rotate-90 scale-0" : "opacity-100 rotate-0 scale-100 text-accent"
        )}
      />
      <Moon
        className={cn(
          "h-4 w-4 absolute transition-all duration-500",
          isDark ? "opacity-100 rotate-0 scale-100 text-accent" : "opacity-0 -rotate-90 scale-0"
        )}
      />
    </button>
  );
};

export default ThemeToggle;
