import { Button } from "@/components/ui/button";
import { ArrowRight, Coffee } from "lucide-react";
import heroImg from "@/assets/hero-cafe.jpg";

const Hero = () => {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      <div className="absolute inset-0">
        <img
          src={heroImg}
          alt="Cozy coffee shop interior at golden hour"
          className="w-full h-full object-cover"
          width={1920}
          height={1080}
        />
        <div className="absolute inset-0 bg-gradient-hero" />
      </div>

      <div className="relative container text-center text-background animate-fade-in-up">
        <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-background/10 backdrop-blur-md border border-background/20 text-sm tracking-wide mb-6">
          <Coffee className="h-4 w-4 text-accent" />
          Since 2010 — Brewed with Passion
        </span>
        <h1 className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold leading-[1.05] mb-6">
          Welcome to <br />
          <span className="text-gradient-warm">Coffee Cafe</span>
        </h1>
        <p className="max-w-2xl mx-auto text-lg md:text-xl text-background/90 mb-10 font-light">
          Exceptional Coffee, Exceptional Experience — Crafted by master baristas,
          served in a place that feels like home.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button variant="hero" size="lg" asChild>
            <a href="#menu">
              Explore Menu <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
          <Button variant="cream" size="lg" asChild>
            <a href="#about">Our Story</a>
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto mt-20 pt-10 border-t border-background/20">
          {[
            { n: "15+", l: "Years Brewing" },
            { n: "50K+", l: "Happy Customers" },
            { n: "20+", l: "Coffee Origins" },
          ].map((s) => (
            <div key={s.l}>
              <div className="font-display text-3xl md:text-4xl font-bold text-accent">{s.n}</div>
              <div className="text-xs md:text-sm text-background/70 mt-1">{s.l}</div>
            </div>
          ))}
        </div>
      </div>

      <a
        href="#about"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-background/70 hover:text-accent transition-colors animate-float"
        aria-label="Scroll down"
      >
        <div className="w-6 h-10 border-2 border-current rounded-full flex justify-center pt-2">
          <div className="w-1 h-2 bg-current rounded-full" />
        </div>
      </a>
    </section>
  );
};

export default Hero;
