import g1 from "@/assets/gallery-1.jpg";
import g2 from "@/assets/gallery-2.jpg";
import g3 from "@/assets/gallery-3.jpg";
import g4 from "@/assets/gallery-4.jpg";
import g5 from "@/assets/gallery-5.jpg";
import g6 from "@/assets/gallery-6.jpg";
import { useReveal } from "@/hooks/useReveal";

const images = [
  { src: g3, alt: "Cozy coffee shop interior with armchairs", cls: "md:col-span-2 md:row-span-2" },
  { src: g1, alt: "Cappuccino with latte art", cls: "" },
  { src: g4, alt: "Barista pouring latte art", cls: "" },
  { src: g5, alt: "Croissant and espresso", cls: "" },
  { src: g6, alt: "Vintage espresso machine", cls: "" },
  { src: g2, alt: "Iced coffee with cream", cls: "md:col-span-2" },
];

const GalleryItem = ({ im, i }: { im: typeof images[number]; i: number }) => {
  const { ref, visible } = useReveal<HTMLDivElement>();
  return (
    <div
      ref={ref}
      className={`group relative overflow-hidden rounded-2xl shadow-card-warm cursor-pointer reveal ${im.cls} ${visible ? "is-visible" : ""}`}
      style={{ transitionDelay: `${i * 90}ms` }}
    >
      <img
        src={im.src}
        alt={im.alt}
        loading="lazy"
        width={800}
        height={800}
        className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-[1100ms] ease-out"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      <div className="absolute inset-x-0 bottom-0 p-5 translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500">
        <p className="text-primary-foreground text-sm font-medium">{im.alt}</p>
      </div>
    </div>
  );
};

const Gallery = () => {
  const { ref, visible } = useReveal<HTMLDivElement>();
  return (
    <section id="gallery" className="py-24 bg-background">
      <div className="container">
        <div ref={ref} className={`text-center max-w-2xl mx-auto mb-14 reveal ${visible ? "is-visible" : ""}`}>
          <span className="text-accent font-semibold tracking-widest uppercase text-sm">Gallery</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-3 mb-4">
            Moments from <span className="text-gradient-warm">Our Cafe</span>
          </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[180px] md:auto-rows-[220px] gap-4">
          {images.map((im, i) => (
            <GalleryItem key={i} im={im} i={i} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;
