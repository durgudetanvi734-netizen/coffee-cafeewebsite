import { Coffee, Facebook, Instagram, Twitter, Youtube } from "lucide-react";

const Footer = () => (
  <footer className="bg-primary text-primary-foreground pt-16 pb-8">
    <div className="container">
      <div className="grid md:grid-cols-4 gap-10 pb-12 border-b border-primary-foreground/10">
        <div className="md:col-span-1">
          <div className="flex items-center gap-2 mb-4 group">
            <Coffee className="h-6 w-6 text-accent group-hover:rotate-12 transition-transform duration-500" />
            <span className="font-display text-2xl font-bold">
              Coffee <span className="text-accent">Cafe</span>
            </span>
          </div>
          <p className="text-primary-foreground/70 text-sm leading-relaxed">
            Crafting exceptional coffee experiences since 2010. A warm haven for every coffee lover.
          </p>
        </div>

        <div>
          <h4 className="font-display text-lg font-semibold mb-4">Explore</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/70">
            {["Menu", "About", "Specials", "Gallery", "Contact"].map((l) => (
              <li key={l}>
                <a href={`#${l.toLowerCase()}`} className="inline-block hover:text-accent hover:translate-x-1 transition-all duration-300">{l}</a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-lg font-semibold mb-4">Visit</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/70">
            <li>123 Brew Street</li>
            <li>Coffee District, NY 10001</li>
            <li>+1 (555) 010-2030</li>
            <li>hello@coffeecafe.com</li>
          </ul>
        </div>

        <div>
          <h4 className="font-display text-lg font-semibold mb-4">Follow Us</h4>
          <div className="flex gap-3">
            {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
              <a
                key={i}
                href="#"
                aria-label="Social link"
                className="h-10 w-10 rounded-full bg-primary-foreground/10 hover:bg-accent hover:text-primary flex items-center justify-center transition-all hover:scale-110"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
      </div>

      <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-3 text-sm text-primary-foreground/60">
        <p>© {new Date().getFullYear()} Coffee Cafe. All rights reserved.</p>
        <div className="flex gap-6">
          <a href="#" className="hover:text-accent">Privacy</a>
          <a href="#" className="hover:text-accent">Terms</a>
          <a href="#" className="hover:text-accent">Cookies</a>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;
