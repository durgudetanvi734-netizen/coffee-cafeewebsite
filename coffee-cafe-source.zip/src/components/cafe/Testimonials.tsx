import { Star, Quote } from "lucide-react";
import { useReveal } from "@/hooks/useReveal";

const reviews = [
  { name: "Sophia Reyes", role: "Coffee Enthusiast", rating: 5, text: "Best latte I've had in the city. The atmosphere makes me want to stay all day. A truly perfect spot." },
  { name: "James Carter", role: "Remote Worker", rating: 5, text: "My favorite work-from-cafe spot. Friendly baristas, fast Wi-Fi, and unbelievably smooth espresso." },
  { name: "Aiko Tanaka", role: "Food Blogger", rating: 5, text: "From the bean selection to the latte art — everything screams craftsmanship. Highly recommended!" },
];

const ReviewCard = ({ r, i }: { r: typeof reviews[number]; i: number }) => {
  const { ref, visible } = useReveal<HTMLElement>();
  return (
    <article
      ref={ref}
      className={`group relative bg-card rounded-2xl p-8 shadow-card-warm hover-lift overflow-hidden reveal ${visible ? "is-visible" : ""}`}
      style={{ transitionDelay: `${i * 130}ms` }}
    >
      <div className="absolute -top-12 -right-12 w-40 h-40 rounded-full bg-gradient-warm opacity-0 group-hover:opacity-10 transition-opacity duration-700" />
      <Quote className="absolute top-5 right-5 h-10 w-10 text-accent/15 group-hover:text-accent/40 group-hover:scale-110 transition-all duration-500" />
      <div className="flex gap-1 mb-4">
        {Array.from({ length: r.rating }).map((_, idx) => (
          <Star
            key={idx}
            className="h-4 w-4 fill-accent text-accent transition-transform duration-300"
            style={{ transitionDelay: `${idx * 60}ms` }}
          />
        ))}
      </div>
      <p className="relative text-foreground/80 leading-relaxed mb-6 italic">"{r.text}"</p>
      <div className="relative flex items-center gap-3 pt-5 border-t border-border">
        <div className="h-11 w-11 rounded-full bg-gradient-warm flex items-center justify-center text-primary-foreground font-semibold group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500">
          {r.name.charAt(0)}
        </div>
        <div>
          <div className="font-semibold">{r.name}</div>
          <div className="text-xs text-muted-foreground">{r.role}</div>
        </div>
      </div>
    </article>
  );
};

const Testimonials = () => {
  const { ref, visible } = useReveal<HTMLDivElement>();
  return (
    <section className="py-24 bg-gradient-cream">
      <div className="container">
        <div ref={ref} className={`text-center max-w-2xl mx-auto mb-16 reveal ${visible ? "is-visible" : ""}`}>
          <span className="text-accent font-semibold tracking-widest uppercase text-sm">Testimonials</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-3 mb-4">
            Loved by <span className="text-gradient-warm">Coffee Lovers</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-7">
          {reviews.map((r, i) => (
            <ReviewCard key={r.name} r={r} i={i} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
