import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail } from "lucide-react";
import { toast } from "sonner";

const Newsletter = () => {
  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    toast.success("Subscribed! Check your inbox for a warm welcome ☕");
    e.currentTarget.reset();
  };

  return (
    <section className="py-20 bg-background">
      <div className="container">
        <div className="group relative overflow-hidden rounded-3xl bg-gradient-warm p-10 md:p-16 shadow-warm text-center hover:shadow-glow transition-shadow duration-700">
          <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-background/10 blur-2xl animate-float" />
          <div className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full bg-primary/30 blur-3xl animate-float" style={{ animationDelay: "1.5s" }} />
          <div className="relative max-w-2xl mx-auto text-primary-foreground">
            <Mail className="h-10 w-10 mx-auto mb-4 opacity-90 group-hover:scale-110 group-hover:-rotate-6 transition-transform duration-500" />
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-4">
              Join Our Coffee Club
            </h2>
            <p className="opacity-90 mb-8">
              Get exclusive offers, brewing tips, and seasonal launches straight to your inbox.
            </p>
            <form onSubmit={onSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <Input
                required
                type="email"
                placeholder="Enter your email"
                className="bg-background/95 border-0 h-12 text-foreground placeholder:text-muted-foreground transition-all focus-visible:ring-accent focus-visible:scale-[1.02]"
              />
              <Button type="submit" size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground h-12 px-6 hover:scale-105 transition-transform">
                Subscribe
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;
