import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Coffee, Menu, User, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import ThemeToggle from "@/components/ThemeToggle";
import { cn } from "@/lib/utils";

const links = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#menu", label: "Menu" },
  { href: "#specials", label: "Specials" },
  { href: "#gallery", label: "Gallery" },
  { href: "#contact", label: "Contact" },
];

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 inset-x-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-background/85 backdrop-blur-lg shadow-card-warm py-3"
          : "bg-transparent py-5"
      )}
    >
      <nav className="container flex items-center justify-between">
        <a href="#home" className="flex items-center gap-2 group">
          <Coffee
            className={cn(
              "h-7 w-7 transition-colors",
              scrolled ? "text-primary" : "text-background"
            )}
          />
          <span
            className={cn(
              "font-display text-2xl font-bold tracking-tight transition-colors",
              scrolled ? "text-primary" : "text-background"
            )}
          >
            Coffee <span className="text-accent">Cafe</span>
          </span>
        </a>

        <ul className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className={cn(
                  "relative text-sm font-medium transition-colors hover:text-accent after:absolute after:left-0 after:-bottom-1 after:h-0.5 after:w-0 after:bg-accent after:transition-all hover:after:w-full",
                  scrolled ? "text-foreground" : "text-background"
                )}
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden md:flex items-center gap-3">
          <ThemeToggle />
          {user ? (
            <Button variant="hero" size="sm" asChild>
              <Link to="/profile">
                <User className="h-4 w-4" /> Profile
              </Link>
            </Button>
          ) : (
            <>
              <Button
                variant={scrolled ? "ghost" : "cream"}
                size="sm"
                asChild
                className={cn(!scrolled && "text-background")}
              >
                <Link to="/auth">Log in</Link>
              </Button>
              <Button variant="hero" size="sm" asChild>
                <Link to="/auth">Sign up</Link>
              </Button>
            </>
          )}
        </div>

        <div className="md:hidden flex items-center gap-2">
          <ThemeToggle />
          <button
            className={cn(
              "p-2 rounded-md transition-colors",
              scrolled ? "text-foreground" : "text-background"
            )}
            onClick={() => setOpen(!open)}
            aria-label="Toggle menu"
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        <button
          className={cn(
            "md:hidden p-2 rounded-md transition-colors",
            scrolled ? "text-foreground" : "text-background"
          )}
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={cn(
          "md:hidden overflow-hidden transition-all duration-300 bg-background/95 backdrop-blur-lg",
          open ? "max-h-[500px] mt-3" : "max-h-0"
        )}
      >
        <ul className="container py-4 flex flex-col gap-4">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                onClick={() => setOpen(false)}
                className="block py-2 text-foreground hover:text-accent font-medium"
              >
                {l.label}
              </a>
            </li>
          ))}
          <li className="flex gap-3 pt-2">
            {user ? (
              <Button variant="hero" size="sm" className="flex-1" asChild>
                <Link to="/profile" onClick={() => setOpen(false)}>Profile</Link>
              </Button>
            ) : (
              <>
                <Button variant="outline" size="sm" className="flex-1" asChild>
                  <Link to="/auth" onClick={() => setOpen(false)}>Log in</Link>
                </Button>
                <Button variant="hero" size="sm" className="flex-1" asChild>
                  <Link to="/auth" onClick={() => setOpen(false)}>Sign up</Link>
                </Button>
              </>
            )}
          </li>
        </ul>
      </div>
    </header>
  );
};

export default Navbar;
