import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { toast } from "sonner";

const info = [
  { icon: MapPin, title: "Visit Us", lines: ["123 Brew Street", "Coffee District, NY 10001"] },
  { icon: Phone, title: "Call Us", lines: ["+1 (555) 010-2030", "Mon–Sun, 7am – 9pm"] },
  { icon: Mail, title: "Email Us", lines: ["hello@coffeecafe.com", "support@coffeecafe.com"] },
  { icon: Clock, title: "Open Hours", lines: ["Mon–Fri: 7am – 9pm", "Sat–Sun: 8am – 10pm"] },
];

const Contact = () => {
  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    toast.success("Message sent! We'll get back to you shortly.");
    e.currentTarget.reset();
  };

  return (
    <section id="contact" className="py-24 bg-gradient-cream">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-accent font-semibold tracking-widest uppercase text-sm">Get in Touch</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-3 mb-4">
            Drop By or <span className="text-gradient-warm">Drop a Line</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-10">
          {/* Info cards */}
          <div className="grid sm:grid-cols-2 gap-5 content-start">
            {info.map(({ icon: Icon, title, lines }, i) => (
              <div
                key={title}
                className="group bg-card rounded-2xl p-6 shadow-card-warm hover-lift animate-fade-in-up"
                style={{ animationDelay: `${i * 100}ms`, animationFillMode: "both" }}
              >
                <div className="h-12 w-12 rounded-xl bg-gradient-warm flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500 shadow-card-warm">
                  <Icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <h3 className="font-display text-xl font-semibold mb-2 group-hover:text-primary transition-colors">{title}</h3>
                {lines.map((l) => (
                  <p key={l} className="text-sm text-muted-foreground">{l}</p>
                ))}
              </div>
            ))}
          </div>

          {/* Form */}
          <form onSubmit={onSubmit} className="bg-card rounded-3xl p-8 md:p-10 shadow-warm space-y-5 hover:shadow-glow transition-shadow duration-700 animate-fade-in-up">
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label className="text-sm font-medium mb-2 block">Name</label>
                <Input required placeholder="Your name" />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Email</label>
                <Input type="email" required placeholder="you@example.com" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Subject</label>
              <Input required placeholder="How can we help?" />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Message</label>
              <Textarea required rows={5} placeholder="Tell us a bit more..." />
            </div>
            <Button type="submit" variant="hero" size="lg" className="w-full">
              Send Message
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contact;
