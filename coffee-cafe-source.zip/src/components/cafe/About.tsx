import { Heart, Leaf, Award } from "lucide-react";
import beans from "@/assets/about-beans.jpg";
import { useReveal } from "@/hooks/useReveal";

const values = [
  { icon: Heart, title: "Crafted with Love", desc: "Every cup is brewed with attention, care, and craft." },
  { icon: Leaf, title: "Ethically Sourced", desc: "Single-origin beans from sustainable farms worldwide." },
  { icon: Award, title: "Award Winning", desc: "Recognized baristas serving competition-grade coffee." },
];

const About = () => {
  const left = useReveal<HTMLDivElement>();
  const right = useReveal<HTMLDivElement>();
  return (
    <section id="about" className="py-24 bg-gradient-cream overflow-hidden">
      <div className="container grid lg:grid-cols-2 gap-16 items-center">
        <div ref={left.ref} className={`relative reveal-left ${left.visible ? "is-visible" : ""}`}>
          <div className="aspect-square rounded-3xl overflow-hidden shadow-warm img-zoom">
            <img
              src={beans}
              alt="Freshly roasted coffee beans"
              loading="lazy"
              width={1200}
              height={1200}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute -top-6 -left-6 w-24 h-24 rounded-full bg-accent/20 blur-2xl animate-float" />
          <div className="absolute -bottom-8 -right-4 md:-right-8 bg-primary text-primary-foreground rounded-2xl p-6 shadow-warm max-w-[220px] hover:scale-105 transition-transform duration-500 animate-float">
            <div className="font-display text-4xl font-bold text-accent">15+</div>
            <div className="text-sm mt-1 opacity-90">Years of perfecting the art of coffee</div>
          </div>
        </div>

        <div ref={right.ref} className={`reveal-right ${right.visible ? "is-visible" : ""}`}>
          <span className="text-accent font-semibold tracking-widest uppercase text-sm">Our Story</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-3 mb-6">
            A Passion Brewed <span className="text-gradient-warm">One Cup at a Time</span>
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-5">
            Coffee Cafe began with a simple dream: to bring people together over an extraordinary cup of coffee.
            From humble beginnings in a small corner shop, we've grown into a beloved haven for coffee lovers,
            remote workers, and friends seeking warmth in every sip.
          </p>
          <p className="text-muted-foreground leading-relaxed mb-8">
            We source the finest single-origin beans, roast them in small batches, and serve them with the kind
            of care that only true coffee artisans can offer.
          </p>

          <div className="space-y-5">
            {values.map(({ icon: Icon, title, desc }, i) => (
              <div
                key={title}
                className="flex gap-4 group p-3 -m-3 rounded-2xl hover:bg-background/40 transition-colors duration-300"
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <div className="shrink-0 h-12 w-12 rounded-xl bg-gradient-warm flex items-center justify-center shadow-card-warm group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500">
                  <Icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-display text-xl font-semibold mb-1 group-hover:text-primary transition-colors">{title}</h3>
                  <p className="text-muted-foreground text-sm">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
