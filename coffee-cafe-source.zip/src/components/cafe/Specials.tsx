import { Sparkles } from "lucide-react";
import g2 from "@/assets/gallery-2.jpg";
import g1 from "@/assets/gallery-1.jpg";
import g6 from "@/assets/gallery-6.jpg";
import { useReveal } from "@/hooks/useReveal";

const specials = [
  { img: g1, name: "Pumpkin Spice Latte", desc: "Warm pumpkin, cinnamon & espresso.", price: "5.90", season: "Autumn" },
  { img: g2, name: "Caramel Cold Brew", desc: "Slow-steeped cold brew with caramel cream.", price: "5.50", season: "Summer" },
  { img: g6, name: "Hazelnut Affogato", desc: "Espresso poured over hazelnut gelato.", price: "6.20", season: "Limited" },
];

const SpecialCard = ({ s, i }: { s: typeof specials[number]; i: number }) => {
  const { ref, visible } = useReveal<HTMLElement>();
  return (
    <article
      ref={ref}
      className={`group bg-background/5 backdrop-blur-sm border border-background/10 rounded-3xl overflow-hidden hover:border-accent/60 transition-all duration-700 hover:-translate-y-3 hover:shadow-glow reveal ${visible ? "is-visible" : ""}`}
      style={{ transitionDelay: `${i * 120}ms` }}
    >
      <div className="aspect-[4/3] overflow-hidden relative">
        <img src={s.img} alt={s.name} loading="lazy" width={800} height={600}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[1200ms] ease-out" />
        <div className="absolute inset-0 bg-gradient-to-t from-primary via-primary/20 to-transparent opacity-60 group-hover:opacity-30 transition-opacity duration-500" />
        <span className="absolute top-4 left-4 text-xs font-semibold tracking-wider uppercase px-3 py-1 rounded-full bg-accent text-accent-foreground transform group-hover:-translate-y-1 transition-transform duration-300">
          {s.season}
        </span>
      </div>
      <div className="p-6">
        <h3 className="font-display text-2xl font-semibold mb-2 group-hover:text-accent transition-colors duration-300">{s.name}</h3>
        <p className="text-primary-foreground/70 text-sm mb-4">{s.desc}</p>
        <div className="flex items-center justify-between">
          <span className="font-display text-2xl font-bold text-accent">${s.price}</span>
          <button className="text-sm font-medium hover:text-accent transition-colors group-hover:translate-x-1 transform duration-300">Add to cart →</button>
        </div>
      </div>
    </article>
  );
};

const Specials = () => {
  const { ref, visible } = useReveal<HTMLDivElement>();
  return (
    <section id="specials" className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_20%_20%,hsl(var(--accent))_0%,transparent_50%)]" />
      <div className="absolute -top-20 -right-20 w-96 h-96 rounded-full bg-accent/10 blur-3xl animate-float" />
      <div className="container relative">
        <div ref={ref} className={`text-center max-w-2xl mx-auto mb-16 reveal ${visible ? "is-visible" : ""}`}>
          <span className="inline-flex items-center gap-2 text-accent font-semibold tracking-widest uppercase text-sm">
            <Sparkles className="h-4 w-4 animate-pulse" /> Seasonal Drinks
          </span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-3 mb-4">
            This Season's <span className="text-accent">Specials</span>
          </h2>
          <p className="text-primary-foreground/70">
            Limited-time creations brewed for the season.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-7">
          {specials.map((s, i) => (
            <SpecialCard key={s.name} s={s} i={i} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Specials;
