import { Coffee } from "lucide-react";
import { useReveal } from "@/hooks/useReveal";

const items = [
  { name: "Espresso", desc: "Bold, rich shot of pure dark-roasted coffee perfection.", price: "3.50", tag: "Classic" },
  { name: "Cappuccino", desc: "Equal parts espresso, steamed milk, and silky foam.", price: "4.50", tag: "Popular" },
  { name: "Caffè Latte", desc: "Smooth espresso with velvety steamed milk and light foam.", price: "4.80", tag: "Signature" },
  { name: "Mocha", desc: "Espresso, chocolate, and steamed milk topped with cream.", price: "5.20", tag: "Sweet" },
  { name: "Iced Coffee", desc: "Slow-brewed cold coffee served over crystal-clear ice.", price: "4.20", tag: "Cold" },
  { name: "Americano", desc: "Espresso lengthened with hot water for a clean finish.", price: "3.80", tag: "Classic" },
];

const MenuCard = ({ item, i }: { item: typeof items[number]; i: number }) => {
  const { ref, visible } = useReveal<HTMLElement>();
  return (
    <article
      ref={ref}
      className={`group relative bg-card rounded-2xl p-7 border border-border hover-lift overflow-hidden reveal ${visible ? "is-visible" : ""}`}
      style={{ transitionDelay: `${i * 90}ms` }}
    >
      <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-gradient-warm opacity-0 group-hover:opacity-20 transition-opacity duration-700" />
      <div className="absolute inset-0 bg-gradient-to-br from-accent/0 via-accent/0 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      <div className="relative flex items-start justify-between mb-4">
        <div className="h-14 w-14 rounded-2xl bg-secondary flex items-center justify-center group-hover:bg-gradient-warm group-hover:rotate-6 group-hover:scale-110 transition-all duration-500">
          <Coffee className="h-6 w-6 text-primary group-hover:text-primary-foreground transition-colors duration-300" />
        </div>
        <span className="text-[10px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded-full bg-accent/10 text-accent group-hover:bg-accent group-hover:text-accent-foreground transition-colors duration-300">
          {item.tag}
        </span>
      </div>
      <h3 className="relative font-display text-2xl font-semibold mb-2 group-hover:text-primary transition-colors">{item.name}</h3>
      <p className="relative text-muted-foreground text-sm leading-relaxed mb-5">{item.desc}</p>
      <div className="relative flex items-center justify-between pt-4 border-t border-dashed border-border">
        <span className="font-display text-2xl font-bold text-primary group-hover:scale-110 origin-left transition-transform duration-300">${item.price}</span>
        <button className="text-sm font-medium text-accent link-underline">
          Order →
        </button>
      </div>
    </article>
  );
};

const Menu = () => {
  const { ref, visible } = useReveal<HTMLDivElement>();
  return (
    <section id="menu" className="py-24 bg-background">
      <div className="container">
        <div ref={ref} className={`text-center max-w-2xl mx-auto mb-16 reveal ${visible ? "is-visible" : ""}`}>
          <span className="text-accent font-semibold tracking-widest uppercase text-sm">Our Menu</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-3 mb-4">
            Crafted Coffee, <span className="text-gradient-warm">Served Fresh</span>
          </h2>
          <p className="text-muted-foreground">
            Discover our handpicked selection of artisanal beverages, each brewed to perfection.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((item, i) => (
            <MenuCard key={item.name} item={item} i={i} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Menu;
